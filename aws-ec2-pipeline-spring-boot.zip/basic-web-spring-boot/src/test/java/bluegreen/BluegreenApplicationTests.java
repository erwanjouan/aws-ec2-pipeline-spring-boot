package bluegreen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BluegreenApplicationTests {

	@Test
	void contextLoads() {
	}

}
