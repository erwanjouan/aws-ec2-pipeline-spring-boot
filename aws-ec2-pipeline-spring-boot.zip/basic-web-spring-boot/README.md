### basic-web-spring-boot

Payload for different types of deployment