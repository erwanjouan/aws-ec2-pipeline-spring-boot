# aws-ec2-pipeline-spring-boot

Amazon EC2 Standard Deployment with CodePipeline

Pipeline reference

https://docs.aws.amazon.com/codepipeline/latest/userguide/reference-pipeline-structure.html#reference-action-artifacts
